_BATCH_ACCOUNT_NAME = 'mbertbatch17'
_BATCH_ACCOUNT_KEY = 'BpeW2DaWcJvS6EzKuTbRSDcBcgLGWvH4IYrHZY7qSj6TOmszkEUz2LY7sxRXpmBnilaltt3UxJsMmDl7redvSw=='
_BATCH_ACCOUNT_URL = 'https://mbertbatch17.canadaeast.batch.azure.com'
_STORAGE_ACCOUNT_NAME = 'mbertsa17'
_STORAGE_ACCOUNT_KEY = 'ZA1ZiJoZNjtKFsDcluCt/o07Ukhc0cehSHSqNPb0J/M76viOTmSpq1YRirybqQ2+coIBBmgnoJ31meBm5bzxCg=='
_POOL_ID = 'X12toXMLPool'
_POOL_NODE_COUNT = 1
_JOB_ID = 'X12toXMLJob'
